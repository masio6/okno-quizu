﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zaj3
{
    internal class Class2
    {
        static public class Decode
        {
            static public string Decoding(string fileString)
            {
                int n = 6;
               dada
                string fileStringDecrypted = "";
                for (int i = 0; i < fileString.Length; i++)
                {
                    int charIndex = fileString[i];
                    fileStringDecrypted += Convert.ToChar(charIndex - n);
                }
                return fileStringDecrypted;
            }
        }
    }
}
