﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zaj3
{
    internal class ParserXML
    {
        public static string PytanieToXML(pytanie p)
        {
            string result = "<Question>\n" + "\t<Pytanie>" + p.pyt + "</Pytanie>\n" +
                "\t<OdpA>" + p.odpa + "</OdpA>\n" +
                "\t<OdpB>" + p.odpb + "</OdpB>\n" +
                "\t<OdpC>" + p.odpc + "</OdpC>\n" +
                "\t<OdpD>" + p.odpd + "</OdpD>\n" +
                "\t<PopOdp>" + p.odpp + "</PopOdp>\n" +
                "</Question>$";

            return result;
        }

        public static pytanie XMLToPytanie(string xmlPytanie)
        {
            string pytanie, odp_a, odp_b, odp_c, odp_d, pop_odp;
            int poczatek, koniec, dlugosc;

            // wyłuskanie pytania
            if (xmlPytanie.Contains("<Question>"))
            {
                poczatek = xmlPytanie.IndexOf("<Pytanie>") + "<Pytanie>".Length;
                koniec = xmlPytanie.IndexOf("</Pytanie>");
                dlugosc = koniec - poczatek;
                pytanie = xmlPytanie.Substring(poczatek, dlugosc);


                // wyłuskanie odpowiedzi
                poczatek = xmlPytanie.IndexOf("<OdpA>") + "<OdpA>".Length;
                koniec = xmlPytanie.IndexOf("</OdpA>");
                dlugosc = koniec - poczatek;
                odp_a = xmlPytanie.Substring(poczatek, dlugosc);

                poczatek = xmlPytanie.IndexOf("<OdpB>") + "<OdpB>".Length;
                koniec = xmlPytanie.IndexOf("</OdpB>");
                dlugosc = koniec - poczatek;
                odp_b = xmlPytanie.Substring(poczatek, dlugosc);

                poczatek = xmlPytanie.IndexOf("<OdpC>") + "<OdpC>".Length;
                koniec = xmlPytanie.IndexOf("</OdpC>");
                dlugosc = koniec - poczatek;
                odp_c = xmlPytanie.Substring(poczatek, dlugosc);

                poczatek = xmlPytanie.IndexOf("<OdpD>") + "<OdpD>".Length;
                koniec = xmlPytanie.IndexOf("</OdpD>");
                dlugosc = koniec - poczatek;
                odp_d = xmlPytanie.Substring(poczatek, dlugosc);

                // wyłuskanie poprawnych odpowiedzi
                poczatek = xmlPytanie.IndexOf("<PopOdp>") + "<PopOdp>".Length;
                koniec = xmlPytanie.IndexOf("</PopOdp>");
                dlugosc = koniec - poczatek;
                pop_odp = xmlPytanie.Substring(poczatek, dlugosc);

            }
            else
                return null;
            pytanie=Class2.Decode.Decoding(pytanie);
            odp_a=Class2.Decode.Decoding(odp_a);
            odp_b=Class2.Decode.Decoding(odp_b);
            odp_c=Class2.Decode.Decoding(odp_c);
                odp_d=Class2.Decode.Decoding(odp_d);
           pop_odp= Class2.Decode.Decoding(pop_odp);
           
            return new pytanie(pytanie, odp_a, odp_b, odp_c, odp_d, pop_odp);

            string odszc(string tek)
            {
                int k = 6, b;

                char[] buffer = tek.ToCharArray();
                for (int i = 0; i < buffer.Length; i++)
                {
                    b = buffer[i] - k;
                    if (b < 0)
                        b = b + 128;
                    buffer[i] = (char)(b);
                }
                string cez = buffer.ToString();
                return cez;


            }



        }


    }
}
