﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace zaj3
{
    /// <summary>
    /// Logika interakcji dla klasy Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
       public static Window2 instance;
        public Window2()
        {
            InitializeComponent();
           instance = this;
        }

        public void spra(object sender, EventArgs e)
        { int k = 0;
            if (int.TryParse(Pytanie11.Text,out k))
            {
                int nr = Int32.Parse(Pytanie11.Text);
                if (nr < MainWindow.instance.dlugosc)
                    MainWindow.instance.wysw();
                else
                    MessageBox.Show("nie ma takiego pytania", "błąd", MessageBoxButton.OK,MessageBoxImage.Error);
            }
            else
                MessageBox.Show("Podana wartość to nie liczba całkowita", "błąd", MessageBoxButton.OK, MessageBoxImage.Error);
        }

       
    }
}
