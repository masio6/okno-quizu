﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using System.Windows.Threading;
using System.Text.Json;
using System.IO;

namespace zaj3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        Window2 wind = new Window2();
        string zle = " Źle odpowiedziałeś na pytania: ";
        int licz=0;
        bool czystart = false;
        public static MainWindow instance;
         int limit = 10;
         public int secondscount = 10;
        List<pytanie>t;
        int ilp = 0;
        bool ostat = false;
        List<string> odpow;
        bool czystop = false;
        public int dlugosc=0;
        private static bool isRun = false;
        bool e = true;
        string odpu ="";
        int ild = 0, ildp = 0;
        System.Timers.Timer timer = new System.Timers.Timer(3000);
        DispatcherTimer disTmr = new DispatcherTimer();
        public MainWindow()
        {
            instance = this;
      
            disTmr.Tick += new EventHandler(disTmr_Tick);
            disTmr.Interval = new TimeSpan(0, 0, 1);
            //string path = @"C:\Users\Admin\Desktop\obiekt\zaj3\dane.xml";
            //string json1 =File.ReadAllText(@"C:\Users\Admin\Desktop\obiekt\zaj3\pbaza.json");


            // t = JsonSerializer.Deserialize<List<pytanie>>(json1);



           
            InitializeComponent();


            t = wczytywanie.Load(@"C:\Users\Admin\Desktop\obiekt\zaj3\dane1.xml");
            
        }
       

        string odszc(string tek)
        {
            int k = 6,b;

            char[] buffer = tek.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                b = buffer[i] - k;
                if (b < 0)
                    b = b + 128;
                buffer[i]= (char)(b);
            }
            string cez = buffer.ToString();
            return cez;

        
        }
        public void wysw()
        { 
            int nr = Int32.Parse(Window2.instance.Pytanie11.Text);
           ilosc.Text = nr.ToString() + "/" + t.Count.ToString();
            Pytanie1.Text = t[nr].pyt;
            odpa.Text = t[nr].odpa;
            odpb.Text = t[nr].odpb;
            odpc.Text = t[nr].odpc;
            odpd.Text = t[nr].odpd;
            Window2.instance.odppp.Text = t[nr].odpp;
            Window2.instance.odpm.Text = t[nr].odpuu;
        }
    
   
        public void st(object sender, EventArgs e)
        {
            
            dlugosc = t.Count;
           
            if (czystart == false)
            {for(int i=0;i<t.Count;i++)
                {
                    t[i].zeruj();
                }
                licz = 0;
                ilosc.Text = licz.ToString() + "/" + t.Count.ToString();
                zle = " Źle odpowiedziałeś na pytania: ";
               
                top = 0;
                secondscount = 10;
                ilp = 0;
               
                disTmr.Start();
                czystart = true;
            }
            else
            {
                if (MessageBox.Show("Czy napewno chcesz zakończyć", "Koniec?", MessageBoxButton.YesNo,MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                 
                    dialog();
                    stop();
                    czystart = false;
                }
                
                dlugosc = t.Count;
            }





        }
        void test()
        { 
            int i = 0;
        while(i<t.Count)
            {
                Pytanie1.Text = t[i].pyt;
                odpa.Text = t[i].odpa;
                odpb.Text = t[i].odpb;
                odpc.Text = t[i].odpc;
                odpd.Text = t[i].odpd;
                while(ostat==false)
                { }
                
                if (ostat == true)
                {
                   
                    sprawdz(t[i]);

                    secondscount = 10;
                    ostat = false;
                    
                }
            }
        
        }
        int top = 0;
        public void disTmr_Tick(object sender, EventArgs e)
        {
            if (top < t.Count)
            {
                Pytanie1.Text = t[top].pyt;
                odpa.Text = t[top].odpa;
                odpb.Text = t[top].odpb;
                odpc.Text = t[top].odpc;
                odpd.Text = t[top].odpd;
                secondscount--;
                CZAS.Text = secondscount + "sec";
                if (secondscount == 0 || ostat == true)
                {
                    t[top].odpuu = odpu;
                    //Pytanie1.Text = t[top].odpd;
                    secondscount = limit;
                    sprawdz(t[top]);
                    top++;
                    odpu = "";
                    button1.Background = Brushes.LightGray;
                    button2.Background = Brushes.LightGray;
                    button4.Background = Brushes.LightGray;
                    button46.Background = Brushes.LightGray;
                    ostat = false;
                }
            }
            else
            {
                dialog();
                stop();
                czystart = false;
            }
       
    
        }
        public void stop()
        {
            disTmr.Stop();
        }
        public void dialog()
        {
            string tek;
            if(ilp!=t.Count)
             tek = "Liczba twoich poprawnych odpowiedzi to: "+ilp.ToString()+" na "+t.Count.ToString()+zle+" czy chesz przejrzeć test?";
          else
             tek = "Liczba twoich poprawnych odpowiedzi to: " + ilp.ToString() + " na " + t.Count.ToString() + " czy chesz przejrzeć test?";
          

            if (MessageBox.Show(tek, "Wyniki", MessageBoxButton.YesNo)==MessageBoxResult.Yes)
            {
              
                    Window2 wind = new Window2();
                 

                wind.ShowDialog();
             
            }
            
           
            
        }
        private void A(object sender, RoutedEventArgs e)
        {
       
            
            if (!odpu.Contains("A"))
            { odpu = odpu + "A";
                button1.Background = Brushes.Green;
            }
            else
            {
                var ELEMENTS = odpu.Split('A');
                odpu = ELEMENTS[0] + ELEMENTS[1];
                button1.Background = Brushes.LightGray;
            }
           
        }
        private void B(object sender, RoutedEventArgs e)
        {
            if (!odpu.Contains("B"))
            {
                odpu = odpu + "B";
                button46.Background = Brushes.Green;
            }
            else
            {
                var ELEMENTS = odpu.Split('B');
                odpu = ELEMENTS[0] + ELEMENTS[1];

                
                button46.Background = Brushes.LightGray;
            }

        }
        private void C(object sender, RoutedEventArgs e)
        {
            if (!odpu.Contains("C"))
            {
                odpu = odpu + "C";
                button2.Background = Brushes.Green;
            }
            else
            {
                var ELEMENTS = odpu.Split('C');
                odpu = ELEMENTS[0] + ELEMENTS[1];
                button2.Background = Brushes.LightGray;
            }
 
        }
        private void D(object sender, RoutedEventArgs e)
        {
            if (!odpu.Contains("D"))
            {
                odpu = odpu + "D";
                button4.Background = Brushes.Green;
            }
            else
            {
                var ELEMENTS = odpu.Split('D');
                odpu = ELEMENTS[0] + ELEMENTS[1];
                button4.Background = Brushes.LightGray;
            }

           
        }

        public void ost(object sender, EventArgs e)
        {
            ostat = true;
         

        }

        void sprawdz(pytanie p)
        {  
                licz++;
                if (p.czyr(odpu))
                {
                    ilp++;
                }
                else
                    zle += top.ToString() + ",";





                ilosc.Text = licz.ToString() + "/" + t.Count.ToString();
            
   
        
        }









    }






}

