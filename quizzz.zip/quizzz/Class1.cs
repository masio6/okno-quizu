﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zaj3
{
    internal class pytanie
    {
      
        public string pyt { get; set; }
        public string odpa { get; set; }
        public string odpb { get; set; }
        public string odpc { get; set; }
        public string odpd { get; set; }
        public string odpp { get; set; }
        public string odpuu = "-";
        private void utw(string pyt, string odpa, string odpb, string odpc, string odpd, string odpp)
        {
           
            this.pyt = pyt;
            this.odpa = odpa;
            this.odpb = odpb;
            this.odpc = odpc;
            this.odpd = odpd;
            this.odpp = odpp;
        }
        public pytanie(string pyt1 = "pytanie", string odpa1 = "odp", string odpb1 = "odp", string odpc1 = "odp", string odpd1 = "odp", string odpp1 = "ABCD")
        {
            pyt = pyt1;
            odpa = odpa1;
            odpb = odpb1;
            odpc = odpc1;
            odpd = odpd1;
            odpp = odpp1;
        }
        public  bool czyr(string odpo)
        { if (this.odpp.Length != odpo.Length)
                return false;
            else
            { for (int i = 0; i < odpo.Length; i++)
                {
                    if (!odpo.Contains(this.odpp[i]))
                        return false;
                }
                        }
            return true;
        }
        public void zeruj()
        {
            this.odpuu = "-";
            
        }
    }
    } 

