﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows;
namespace zaj3
{
    internal class wczytywanie
    {
        public static List<pytanie> Load(string path)
        {
           
            List<pytanie> quiz = new List<pytanie>();

            if (File.Exists(path))
            {
                string dane = File.ReadAllText(path);
                if (dane.Trim() == "")
                    return quiz;

                string[] pytania = dane.Split('$');

                foreach (string pytanie in pytania)
                    quiz.Add(ParserXML.XMLToPytanie(pytanie.Trim()));
            }
            else
            {
                MessageBox.Show("Plik z danymi nie istnieje!");
            }

            return quiz;
        }

    }
}
